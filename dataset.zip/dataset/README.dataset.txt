# Dental Anomaly Detection > 2025-08-22 9:57pm
https://universe.roboflow.com/raul-awfmc/dental-anomaly-detection-igtps-tmkrf

Provided by a Roboflow user
License: CC BY 4.0

